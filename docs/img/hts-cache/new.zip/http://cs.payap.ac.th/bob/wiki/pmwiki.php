<!DOCTYPE html 
	PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
        <link rel="shortcut icon" type="image/x-icon" href="/bob/favicon.ico">
	<title>Ajarn Bob Batzinger - Main - HomePage</title>
	<meta http-equiv="Content-Type" content="text/html" />
	
    <link href='http://cs.payap.ac.th/bob/wiki/pub/skins/triad/css/pm-core.css' rel='stylesheet' type='text/css' />
<!--HTMLHeader--><style type='text/css'><!--a.varlink { text-decoration:none; }

  #sidebar { width: 170px; }  
  #rightbar { width: 170px; }

--></style><meta http-equiv='Content-Type' content='text/html; charset=utf-8' />  <meta name='robots' content='index,follow' />

<script type='text/javascript' >
    var fontSizeDefault = 90;
    var increment = 10;
    var cookieName = 'setfontsize';
    var fsLabel = 'Text Size';
    var fsBigger = 'bigger';
    var fsNormal = 'default';
    var fsSmaller = 'smaller';
 </script>
<script type='text/javascript' src='http://cs.payap.ac.th/bob/wiki/pub/skins/triad/fontsizer.js'></script>

<script type='text/javascript' >
    var toggleCookies = '1';
    var lcookie = 'triad_setLshow';
    var rcookie = 'triad_setRshow';
    var lshow = '1';
    var rshow = '1';
    var show = 'Show';
    var hide = 'Hide';
    var lwidth = '170px';
    var rwidth = '170px';
</script>
<script type='text/javascript' src='http://cs.payap.ac.th/bob/wiki/pub/skins/triad/togglebars.js'></script>

   <link href='http://cs.payap.ac.th/bob/wiki/pub/skins/triad/css/layout-triad.css' rel='stylesheet' type='text/css' />
   <link href='http://cs.payap.ac.th/bob/wiki/pub/skins/triad/css/layout-main.css' rel='stylesheet' type='text/css' />
   <link href='http://cs.payap.ac.th/bob/wiki/pub/skins/triad/css/layout-print.css' rel='stylesheet' type='text/css' media='print' />  
   <link href='http://cs.payap.ac.th/bob/wiki/pub/skins/triad/css/font-verdana.css' rel='stylesheet' type='text/css' media='screen' />   
   <link href='http://cs.payap.ac.th/bob/wiki/pub/skins/triad/css/c-lightblue.css' rel='stylesheet' type='text/css' media='screen' />
   
  <style type='text/css'>
  pre {	white-space: pre-wrap; /* css-3 */
	white-space: -moz-pre-wrap; /* Mozilla, since 1999 */
	white-space: -pre-wrap; /* Opera 4-6 */
	white-space: -o-pre-wrap; /* Opera 7 */
	*break-word: break-all; /* Internet Explorer 7 */
	*white-space: pre;
	* html pre { white-space: normal; /* old IE */ }	
	</style>
  

</head>

<body >
 <script type='text/javascript' ><!--
   document.cookie = 'javascript=1; path=/';
   if (fontSize) { fontSize.fontSizeInit();}
//   document.write("<a href='#'></a >");
 --></script>
<table id="outer-box" border="0" cellspacing="0" cellpadding="0" >
<tr>
<td id="header-box" colspan="3" valign="top">

<!--PageHeaderFmt-->
 <div id='header' class='pageheader'><div class='lfloat' > 
<div><a class='urllink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php' rel='nofollow'><img src='http://cs.payap.ac.th/bob/wiki/pub/skins/triad/images/csresearch.png' alt='' title='' /></a></div>
</div><div class='lfloat' > 
<p class='vspace'><a class='urllink' href='http://cs.payap.ac.th/bob/' rel='nofollow'><span  style='color: blue;'><span style='font-size:83%'><strong>Robert Batzinger</strong></span></span></a><br clear='all' /> <span  style='color: blue;'> <span style='font-size:69%'>CS Research Projects</span> </span>
</p><form  class='wikisearch' action='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.HomePage' method='get'><div><input type='text' name='q' value='Search' class='inputbox searchbox' size='18' 
    onfocus="preval=this.value; this.value=''; "  /> <input type='submit' class='inputbutton searchbutton' value='Go' /><input type='hidden' name='focus' value='on' /><input type='hidden' name='action' value='search' /><input type='hidden' name='n' value='Main.HomePage' /></div></form><span class='inputbutton'><a class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.HomePage?setview=big&amp;setfontsize=110'><span style='font-size:83%'>Big View</span></a></span> <span style='font-size:83%'> 
    <script type='text/javascript' >
    <!--
      if (fsinit==1) document.write(fontSize.allLinks);
      else if (fontSize) { 
          fontSize.fontSizeInit();
          document.write(fontSize.allLinks); }
    --></script>  
 </span>
</div>

  <div class="clearer"><!-- this is a clearer div --></div>
 </div>
<!--/PageHeaderFmt-->

<!--PageTopMenuFmt-->
 <div id="topnavbox">
  <div id="topnav" class="nav">
   <div id="toggleleft">
   <script type='text/javascript' ><!--
   if (toggleLeft) document.write("<input name='lb' type='button' class='togglebox' value='Hide &darr;' onclick='toggleLeft()' />") 
   --></script>
   </div>
   <div id="toggleright"></div>
	  	<div class='lnav' > 
<ul><li><a class='selflink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.HomePage'>Home</a>
</li></ul></div>
<div class='rnav' > 
<ul><li><span class='accesskey'><a rel='nofollow'  class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.HomePage?action=print'>Print</a></span>
</li></ul></div>

 </div></div>
<!--/PageTopMenuFmt-->
</td>
</tr>

<tr>
<!--PageLeftFmt-->
<td id="left-box" valign="top">
 <div id='sidebar'>
  <div id='sidebarpage'><h1>Current Projects</h1>
<ul><li><a class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.ThaiBehaviorDrivenDev'>ThaiBDD</a>
</li><li><span class='wikiword'><a class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.ThaiLectureSlides'>ThaiLectureSlides</a></span>
</li><li><span class='wikiword'><a class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.GraphProgDesign'>GraphProgDesign</a></span>
</li><li><span class='wikiword'><a class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.ThaiMetafont'>ThaiMetafont</a></span>
</li><li><span class='wikiword'><a class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.CSRetainology'>CSRetainology</a></span>
</li><li><span class='wikiword'><a class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.FreshmenCompSci'>FreshmenCompSci</a></span>
</li><li><span class='wikiword'><a class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.PhotoFeatureMorph'>PhotoFeatureMorph</a></span>
</li><li><span class='wikiword'><a class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.UndergradCSEd'>UndergradCSEd</a></span>
</li><li><span class='wikiword'><a class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.InterCollegeDevel'>InterCollegeDevel</a></span>
<div class='vspace'></div></li><li><span class='wikiword'><a class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.SupervisedProjects'>SupervisedProjects</a></span> 
</li></ul><div class='vspace'></div><h1>Other links</h1>
<ul><li><span class='wikiword'><a class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.TeachingParadigms'>TeachingParadigms</a></span>
</li><li><span class='wikiword'><a class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.AboutThisSite'>AboutThisSite</a></span>
</li><li><span class='wikiword'><a class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.ContactInfo'>ContactInfo</a></span>
<div class='vspace'></div></li><li><a class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.Login?action=login'>Login</a> 
</li></ul><div class='vspace'></div>
</div>
  <div id="sidebarfooter">
   
  </div>
 </div>
</td><!-- end div left -->
<!--/PageLeftFmt-->
<td id="center-box" valign="top">
 <div id="contentbox">

<!--PageTitleFmt-->
  <div id= 'titlebarbox'>
   <div id='titlebar' >
	   <div class='pagegroup' > 
<p><a class='selflink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.HomePage'>Main</a>
</p></div><div class='pagetitle' style='text-align: center;' > 
<h1><a class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.HomePage?action=browse'>Home Page</a></h1>
</div>

	 </div>
	</div>
<!--/PageTitleFmt-->
  <div id='content'>

<!--PageText-->
<div id='wikitext'>
<h1>Directory of Research Projects:</h1>
<p>The following is a list of research projects that are housed in this site.
</p>
<div class='vspace'></div><h2>Current research activities</h2>
<ul><li><span class='wikiword'><a class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.ThaiBehaviorDrivenDev'>ThaiBehaviorDrivenDev</a></span> - Use of Thai version of Cucumber to include end-user in  behavior driven design and software testing
</li><li><span class='wikiword'><a class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.GraphicProgDesign'>GraphicProgDesign</a></span> - Use of yEd as a Ruby CASE tool
</li><li><span class='wikiword'><a class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.ThaiLectureSlides'>ThaiLectureSlides</a></span> - Development of Thai lecture slides and handouts in Thai using the Beamer compiled under XeLaTeX
</li><li><span class='wikiword'><a class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.ThaiMetafont'>ThaiMetafont</a></span> - Redevelopment of a Thai Metafont lost 20 years ago
</li><li><span class='wikiword'><a class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.CSRetainology'>CSRetainology</a></span> - Implementation and calibration of a Thai student retention system within the Faculty of Science
</li><li><span class='wikiword'><a class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.FreshmenCompSci'>FreshmenCompSci</a></span> - Improving interest, grades and retention of freshmen computer science students using Scratch, Processing and various active learning techniques
</li><li><span class='wikiword'><a class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.PhotoFeatureMorph'>PhotoFeatureMorph</a></span> - preliminary mathematical studies to identify a feature in a photograph and replace it with another.
</li><li><span class='wikiword'><a class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.UndergradCSEd'>UndergradCSEd</a></span> - An attempt to describe and align the philosophical goals of students with the expectations of the professional community
</li><li><span class='wikiword'><a class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.InterCollegeDevel'>InterCollegeDevel</a></span> - A project to develop an international Research and Development Program at Payap University International College
</li><li><span class='wikiword'><a class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.InterCollegeWeb'>InterCollegeWeb</a></span> - A project workspace for developing ideas for the International College Website
</li></ul><div class='vspace'></div><h2>Supervised Student Projects</h2>
<div class='indent'><span class='wikiword'><a class='wikilink' href='http://cs.payap.ac.th/bob/wiki/pmwiki.php?n=Main.SupervisedProjects'>SupervisedProjects</a></span> CS499 projects supervised by Dr Batzinger
</div>
</div>

	  <div class="clearer"><!-- this is a clearer div --></div>
	</div>
 </div><!-- end div contentbox -->
<!--PageFootMenuFmt-->
 <div id ='footnavbox'>
  <div id='footnav' class='navbuttons'></div>
 </div>
<!--/PageFootMenuFmt-->
</td><!-- end div center -->

<!--PageRightFmt--><!--/PageRightFmt-->
</tr>

<tr>
<!--PageFooterFmt-->
 <td id="footer-box" colspan="3" valign="top">
	<div id="footer"><p  style='text-align: center;'>  &copy; 2012 by Robert Batzinger. All rights reserved.
</p>
</div>
 </td>
<!--/PageFooterFmt-->
</tr>
</table><!-- end div outer -->
<!--HTMLFooter-->
</body>
</html>
